package com.lcwd.rating.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.lcwd.rating.entities.Rating;
import com.lcwd.rating.services.RatingService;

@RestController
@RequestMapping("/ratings")
public class RatingController {
//create
	@Autowired
	private RatingService ratingService;
	@PostMapping
	public  Rating create(@RequestBody Rating rating) {
		return ratingService.create(rating);
		
	}
	//getall
	@GetMapping
	public List<Rating> getRatings(){
		return ratingService.getRatings();
	}
	//by userid
	@GetMapping("/users/{userId}")
	public List<Rating> getRatingByUserId(@PathVariable String userId){
		System.out.println(userId);
		return ratingService.getRatingsByUserId(userId);
	}
	//by hotel id
	@GetMapping("/hotels/{hotelId}")
	public List<Rating> getRatingsByHotelId(@PathVariable String hotelId){
		return ratingService.getRatingsByHotelId(hotelId);
	}
}
