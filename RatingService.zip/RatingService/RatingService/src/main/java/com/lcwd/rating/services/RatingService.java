package com.lcwd.rating.services;

import java.util.List;

import com.lcwd.rating.entities.Rating;



public interface RatingService {
	//user operation
		//create
		Rating create(Rating rating);
		//get all user
		List<Rating> getRatings();
		//get rarting  with given userid 
		List<Rating> getRatingsByUserId(String userId);
		
		//get all by hotel
		
		List<Rating> getRatingsByHotelId(String hotelId);
		
}
