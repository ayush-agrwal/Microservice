package com.lcwd.user.service.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import org.hibernate.annotations.common.util.impl.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;

import com.lcwd.user.service.entities.Rating;
import com.lcwd.user.service.entities.User;
import com.lcwd.user.service.exceptions.ResourceNotFoundException;
import com.lcwd.user.service.repositories.UserRepo;
import com.lcwd.user.service.services.UserServices;

import ch.qos.logback.classic.Logger;

@Service
public class UserServiceImpl implements UserServices {

	@Autowired
	UserRepo userRepo;
	
	@Autowired
	private RestTemplate restTemplate ;
	
	//private Logger logger=LoggerFactory.logger(getClass('UserServices.class'))
	
	@Override
	public User saveUser(User user) {
		// TODO Auto-generated method stub
		String randomUserId=UUID.randomUUID().toString();
		user.setUserId(randomUserId);
		return userRepo.save(user);
	}

	@Override
	public List<User> getUsers() {
		// TODO Auto-generated method stub
		return userRepo.findAll();
	}

	@Override
	public User getUser(String userId) {
		// get user by id 
		User user=userRepo.findById(userId).orElseThrow(()->new ResourceNotFoundException("user not found on the server"+userId));
		//fetech the rating of above from rating services   
		// for will use the rating serice api
		// using this api http://localhost:8085/ratings/users/54988910-873f-41b5-87e5-68a4d1b3fa88
		
		ResponseEntity<Rating[]> responseEntity = restTemplate.getForEntity("http://RATINGSERVICE/ratings/users/" + user.getUserId(), Rating[].class);
		Rating[] ratingOfUser = responseEntity.getBody();
		List<Rating> ratings=Arrays.stream(ratingOfUser).toList();
		List<Rating> ratingList=ratings.stream().map(rating ->{
			
			System.out.println("Hotel Id "+rating.getHotelId());
			
			ResponseEntity<com.lcwd.user.service.entities.Hotel> hotelResponseEntity=restTemplate.getForEntity("http://HOTELSERVICE/hotel/"+rating.getHotelId(),com.lcwd.user.service.entities.Hotel.class);
			
			com.lcwd.user.service.entities.Hotel hotel=hotelResponseEntity.getBody();
			
			rating.setHotel(hotel);
			return rating;
			
		}).collect(Collectors.toList());
		user.setRatings(ratingList);
		
				 // Iterate through ratings and send hotelId to another service to implement the hotel
	            /*for (Rating rating : ratings) {
	                String hotelId = rating.getHotelId();
	                System.out.println("hotelId "+hotelId);
	            }*/
				
		
		
		
		return user;
	}
  
}
