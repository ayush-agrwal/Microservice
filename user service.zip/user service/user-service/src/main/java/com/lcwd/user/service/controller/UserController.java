package com.lcwd.user.service.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.lcwd.user.service.entities.User;
import com.lcwd.user.service.services.UserServices;

@RestController
@RequestMapping("/users")
public class UserController {
	@Autowired
	private UserServices userServices;
	//create
	@PostMapping
	public User createUser(@RequestBody User user)
	{
		User user1=userServices.saveUser(user);
		return user1;
		
	}
	
	//get user naem by id
	@GetMapping("/{userId}")
	public User getSingleUser(@PathVariable String userId) {
		System.out.println(userServices.getUser(userId));
		User user2=userServices.getUser(userId);
		return user2;
	}
	@GetMapping
	
public List<User> getAllUser(){
	System.out.println(userServices.getUsers());
	return userServices.getUsers();
	
}
	
}
