package com.lcwd.user.service.services;

import java.util.List;

import com.lcwd.user.service.entities.User;

public interface UserServices {

	//user operation
	//create
	User saveUser(User user);
	//get all user
	List<User> getUsers();
	//get user with given id 
	User getUser(String userId);
}
