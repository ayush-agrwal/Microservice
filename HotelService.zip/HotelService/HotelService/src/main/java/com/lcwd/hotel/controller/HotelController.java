package com.lcwd.hotel.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.lcwd.hotel.entities.Hotel;
import com.lcwd.hotel.services.HotelServices;

@RestController
@RequestMapping("/hotel")
public class HotelController {

	@Autowired
	private HotelServices hotelServices;
	//create 
	@PostMapping
	public Hotel createHotel(@RequestBody Hotel hotel) {
		return hotelServices.create(hotel);
		
	}
	//get single
	@GetMapping("/{hotelId}")
	public Hotel getHotel(@PathVariable String hotelId) {
		return hotelServices.get(hotelId);
		
	}
	
	//get all
	@GetMapping
	public List<Hotel> getAll(){
		return hotelServices.getAll();
	}
} 
